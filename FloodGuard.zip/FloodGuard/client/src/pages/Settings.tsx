import Header from "@/components/Header";
import MobileNav from "@/components/MobileNav";
import { useLanguage } from "@/hooks/useLanguage";

export default function Settings() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="text-center py-20">
          <h1 className="text-3xl font-bold text-foreground mb-4">{t("settings")}</h1>
          <p className="text-muted-foreground">Settings page implementation coming soon...</p>
        </div>
      </main>

      <MobileNav />
    </div>
  );
}
