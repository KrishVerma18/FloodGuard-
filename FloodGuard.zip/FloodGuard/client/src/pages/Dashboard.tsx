import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import Header from "@/components/Header";
import MobileNav from "@/components/MobileNav";
import AlertBanner from "@/components/AlertBanner";
import StatsCard from "@/components/StatsCard";
import WaterLevelsCard from "@/components/WaterLevelsCard";
import MapCard from "@/components/MapCard";
import HistoricalDataCard from "@/components/HistoricalDataCard";
import AlertsPanel from "@/components/AlertsPanel";
import EmergencyContacts from "@/components/EmergencyContacts";
import NotificationSettings from "@/components/NotificationSettings";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useLanguage } from "@/hooks/useLanguage";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { t } = useLanguage();
  const [latestReadings, setLatestReadings] = useState<any[]>([]);
  const [activeAlerts, setActiveAlerts] = useState<any[]>([]);

  // Fetch dashboard statistics
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  // Fetch monitoring stations
  const { data: stations, isLoading: stationsLoading } = useQuery({
    queryKey: ["/api/stations"],
  });

  // WebSocket connection for real-time updates
  useWebSocket({
    onMessage: (message) => {
      switch (message.type) {
        case "initial_data":
          setLatestReadings(message.data.latestReadings || []);
          setActiveAlerts(message.data.alerts || []);
          break;
        case "readings_update":
          setLatestReadings(message.data || []);
          break;
        case "alerts_update":
          setActiveAlerts(message.data || []);
          break;
      }
    },
  });

  const isLoading = statsLoading || stationsLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <Skeleton className="h-96 w-full" />
              <Skeleton className="h-80 w-full" />
            </div>
            <div className="space-y-6">
              <Skeleton className="h-64 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          </div>
        </div>
        <MobileNav />
      </div>
    );
  }

  // Get critical alerts for banner
  const criticalAlerts = activeAlerts.filter(alert => 
    alert.severity === "critical" || alert.alertType === "flood"
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Critical Alerts Banner */}
      {criticalAlerts.length > 0 && (
        <AlertBanner alerts={criticalAlerts} />
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6">
          <button className="flex-1 bg-card text-foreground px-4 py-2 rounded-md font-medium shadow-sm" data-testid="tab-dashboard">
            <i className="fas fa-tachometer-alt mr-2"></i>{t("dashboard")}
          </button>
          <button className="flex-1 text-muted-foreground px-4 py-2 rounded-md font-medium hover:text-foreground" data-testid="tab-map">
            <i className="fas fa-map mr-2"></i>{t("map_view")}
          </button>
          <button className="flex-1 text-muted-foreground px-4 py-2 rounded-md font-medium hover:text-foreground" data-testid="tab-alerts">
            <i className="fas fa-bell mr-2"></i>{t("alerts")}
          </button>
          <button className="flex-1 text-muted-foreground px-4 py-2 rounded-md font-medium hover:text-foreground" data-testid="tab-analytics">
            <i className="fas fa-chart-line mr-2"></i>{t("analytics")}
          </button>
          <button className="flex-1 text-muted-foreground px-4 py-2 rounded-md font-medium hover:text-foreground" data-testid="tab-settings">
            <i className="fas fa-cog mr-2"></i>{t("settings")}
          </button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title={t("active_monitors")}
            value={stats?.activeMonitors ?? 0}
            subtitle={`${stats?.monitorUptime ?? 0}% ${t("online")}`}
            icon="fas fa-satellite-dish"
            variant="primary"
            trend="up"
          />
          
          <StatsCard
            title={t("active_alerts")}
            value={stats?.activeAlerts ?? 0}
            subtitle={t("high_priority")}
            icon="fas fa-exclamation-triangle"
            variant="destructive"
            trend="warning"
          />
          
          <StatsCard
            title={t("people_notified")}
            value={stats?.peopleNotified ?? 0}
            subtitle={t("last_24h")}
            icon="fas fa-users"
            variant="success"
            trend="up"
          />
          
          <StatsCard
            title={t("safe_zones")}
            value={`${stats?.safeZonePercentage ?? 0}%`}
            subtitle={t("all_districts")}
            icon="fas fa-shield-alt"
            variant="success"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Dashboard Content */}
          <div className="lg:col-span-2 space-y-6">
            <WaterLevelsCard 
              readings={latestReadings} 
              stations={stations ?? []} 
            />
            <MapCard 
              stations={stations ?? []} 
              readings={latestReadings}
              breakdown={stats?.stationBreakdown ?? { safe: 0, warning: 0, danger: 0 }}
            />
            <HistoricalDataCard stationId="BR-001" />
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            <AlertsPanel alerts={activeAlerts} />
            <EmergencyContacts />
            <NotificationSettings />
          </div>
        </div>
      </main>

      <MobileNav />
    </div>
  );
}
