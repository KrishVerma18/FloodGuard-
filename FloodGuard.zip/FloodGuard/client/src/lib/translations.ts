export type Language = "en" | "hi" | "bn" | "as";

export type TranslationKey = 
  | "app_title"
  | "dashboard"
  | "map_view"
  | "alerts"
  | "analytics"
  | "settings"
  | "emergency"
  | "flood_warning"
  | "water_level_warning"
  | "active_monitors"
  | "active_alerts"
  | "people_notified"
  | "safe_zones"
  | "online"
  | "high_priority"
  | "last_24h"
  | "all_districts"
  | "real_time_water_levels"
  | "live"
  | "danger"
  | "warning"
  | "normal_range"
  | "monitoring_stations_map"
  | "real_time_status"
  | "safe_stations"
  | "warning_stations"
  | "danger_stations"
  | "water_level_trends"
  | "last_24_hours"
  | "last_7_days"
  | "last_30_days"
  | "average_level"
  | "peak_level"
  | "change_24h"
  | "active_alerts_panel"
  | "current_flood_warnings"
  | "send_alert"
  | "monitor"
  | "view"
  | "emergency_contacts"
  | "quick_access_authorities"
  | "call"
  | "alert_settings"
  | "configure_notifications"
  | "sms_alerts"
  | "receive_flood_warnings_sms"
  | "email_notifications"
  | "daily_summary_reports"
  | "push_notifications"
  | "real_time_mobile_alerts"
  | "test_alerts"
  | "map"
  | "ndrf"
  | "state_control_room"
  | "medical_emergency"
  | "weather_dept"
  | "system_update";

export const translations: Record<Language, Record<TranslationKey, string>> = {
  en: {
    app_title: "Flood Monitor Pro",
    dashboard: "Dashboard",
    map_view: "Map View",
    alerts: "Alerts",
    analytics: "Analytics",
    settings: "Settings",
    emergency: "Emergency",
    flood_warning: "FLOOD WARNING",
    water_level_warning: "WATER LEVEL WARNING",
    active_monitors: "Active Monitors",
    active_alerts: "Active Alerts",
    people_notified: "People Notified",
    safe_zones: "Safe Zones",
    online: "Online",
    high_priority: "High Priority",
    last_24h: "Last 24h",
    all_districts: "All Districts",
    real_time_water_levels: "Real-time Water Levels",
    live: "Live",
    danger: "Danger",
    warning: "Warning",
    normal_range: "Normal Range",
    monitoring_stations_map: "Monitoring Stations Map",
    real_time_status: "Real-time status of all monitoring stations",
    safe_stations: "Safe",
    warning_stations: "Warning",
    danger_stations: "Danger",
    water_level_trends: "Water Level Trends",
    last_24_hours: "Last 24 Hours",
    last_7_days: "Last 7 Days",
    last_30_days: "Last 30 Days",
    average_level: "Average Level",
    peak_level: "Peak Level",
    change_24h: "24h Change",
    active_alerts_panel: "Active Alerts",
    current_flood_warnings: "Current flood warnings",
    send_alert: "Send Alert",
    monitor: "Monitor",
    view: "View",
    emergency_contacts: "Emergency Contacts",
    quick_access_authorities: "Quick access to authorities",
    call: "Call",
    alert_settings: "Alert Settings",
    configure_notifications: "Configure notification preferences",
    sms_alerts: "SMS Alerts",
    receive_flood_warnings_sms: "Receive flood warnings via SMS",
    email_notifications: "Email Notifications",
    daily_summary_reports: "Daily summary reports",
    push_notifications: "Push Notifications",
    real_time_mobile_alerts: "Real-time mobile alerts",
    test_alerts: "Test Alerts",
    map: "Map",
    ndrf: "NDRF",
    state_control_room: "State Control Room",
    medical_emergency: "Medical Emergency",
    weather_dept: "IMD Weather",
    system_update: "SYSTEM UPDATE",
  },
  hi: {
    app_title: "बाढ़ मॉनिटर प्रो",
    dashboard: "डैशबोर्ड",
    map_view: "मैप व्यू",
    alerts: "अलर्ट",
    analytics: "एनालिटिक्स",
    settings: "सेटिंग्स",
    emergency: "आपातकाल",
    flood_warning: "बाढ़ चेतावनी",
    water_level_warning: "जल स्तर चेतावनी",
    active_monitors: "सक्रिय मॉनिटर",
    active_alerts: "सक्रिय अलर्ट",
    people_notified: "सूचित लोग",
    safe_zones: "सुरक्षित क्षेत्र",
    online: "ऑनलाइन",
    high_priority: "उच्च प्राथमिकता",
    last_24h: "पिछले 24 घंटे",
    all_districts: "सभी जिले",
    real_time_water_levels: "वास्तविक समय जल स्तर",
    live: "लाइव",
    danger: "खतरा",
    warning: "चेतावनी",
    normal_range: "सामान्य सीमा",
    monitoring_stations_map: "निगरानी स्टेशन मैप",
    real_time_status: "सभी निगरानी स्टेशनों की वास्तविक समय स्थिति",
    safe_stations: "सुरक्षित",
    warning_stations: "चेतावनी",
    danger_stations: "खतरा",
    water_level_trends: "जल स्तर रुझान",
    last_24_hours: "पिछले 24 घंटे",
    last_7_days: "पिछले 7 दिन",
    last_30_days: "पिछले 30 दिन",
    average_level: "औसत स्तर",
    peak_level: "शिखर स्तर",
    change_24h: "24 घंटे में बदलाव",
    active_alerts_panel: "सक्रिय अलर्ट",
    current_flood_warnings: "वर्तमान बाढ़ चेतावनी",
    send_alert: "अलर्ट भेजें",
    monitor: "निगरानी",
    view: "देखें",
    emergency_contacts: "आपातकालीन संपर्क",
    quick_access_authorities: "अधिकारियों तक त्वरित पहुंच",
    call: "कॉल करें",
    alert_settings: "अलर्ट सेटिंग्स",
    configure_notifications: "सूचना प्राथमिकताएं कॉन्फ़िगर करें",
    sms_alerts: "SMS अलर्ट",
    receive_flood_warnings_sms: "SMS के माध्यम से बाढ़ चेतावनी प्राप्त करें",
    email_notifications: "ईमेल सूचनाएं",
    daily_summary_reports: "दैनिक सारांश रिपोर्ट",
    push_notifications: "पुश सूचनाएं",
    real_time_mobile_alerts: "वास्तविक समय मोबाइल अलर्ट",
    test_alerts: "टेस्ट अलर्ट",
    map: "मैप",
    ndrf: "NDRF",
    state_control_room: "राज्य नियंत्रण कक्ष",
    medical_emergency: "चिकित्सा आपातकाल",
    weather_dept: "IMD मौसम",
    system_update: "सिस्टम अपडेट",
  },
  bn: {
    app_title: "বন্যা মনিটর প্রো",
    dashboard: "ড্যাশবোর্ড",
    map_view: "ম্যাপ ভিউ",
    alerts: "সতর্কতা",
    analytics: "অ্যানালিটিক্স",
    settings: "সেটিংস",
    emergency: "জরুরি অবস্থা",
    flood_warning: "বন্যা সতর্কতা",
    water_level_warning: "জলস্তর সতর্কতা",
    active_monitors: "সক্রিয় মনিটর",
    active_alerts: "সক্রিয় সতর্কতা",
    people_notified: "অবহিত মানুষ",
    safe_zones: "নিরাপদ অঞ্চল",
    online: "অনলাইন",
    high_priority: "উচ্চ অগ্রাধিকার",
    last_24h: "গত ২৪ ঘন্টা",
    all_districts: "সকল জেলা",
    real_time_water_levels: "রিয়েল-টাইম জলস্তর",
    live: "লাইভ",
    danger: "বিপদ",
    warning: "সতর্কতা",
    normal_range: "স্বাভাবিক পরিসর",
    monitoring_stations_map: "মনিটরিং স্টেশন ম্যাপ",
    real_time_status: "সকল মনিটরিং স্টেশনের রিয়েল-টাইম অবস্থা",
    safe_stations: "নিরাপদ",
    warning_stations: "সতর্কতা",
    danger_stations: "বিপদ",
    water_level_trends: "জলস্তর প্রবণতা",
    last_24_hours: "গত ২৪ ঘন্টা",
    last_7_days: "গত ৭ দিন",
    last_30_days: "গত ৩০ দিন",
    average_level: "গড় স্তর",
    peak_level: "সর্বোচ্চ স্তর",
    change_24h: "২৪ ঘন্টার পরিবর্তন",
    active_alerts_panel: "সক্রিয় সতর্কতা",
    current_flood_warnings: "বর্তমান বন্যা সতর্কতা",
    send_alert: "সতর্কতা পাঠান",
    monitor: "নিরীক্ষণ",
    view: "দেখুন",
    emergency_contacts: "জরুরি যোগাযোগ",
    quick_access_authorities: "কর্তৃপক্ষের সাথে দ্রুত যোগাযোগ",
    call: "কল করুন",
    alert_settings: "সতর্কতা সেটিংস",
    configure_notifications: "বিজ্ঞপ্তি পছন্দ কনফিগার করুন",
    sms_alerts: "SMS সতর্কতা",
    receive_flood_warnings_sms: "SMS এর মাধ্যমে বন্যা সতর্কতা পান",
    email_notifications: "ইমেইল বিজ্ঞপ্তি",
    daily_summary_reports: "দৈনিক সারসংক্ষেপ রিপোর্ট",
    push_notifications: "পুশ বিজ্ঞপ্তি",
    real_time_mobile_alerts: "রিয়েল-টাইম মোবাইল সতর্কতা",
    test_alerts: "টেস্ট সতর্কতা",
    map: "ম্যাপ",
    ndrf: "NDRF",
    state_control_room: "রাজ্য নিয়ন্ত্রণ কক্ষ",
    medical_emergency: "চিকিৎসা জরুরি অবস্থা",
    weather_dept: "IMD আবহাওয়া",
    system_update: "সিস্টেম আপডেট",
  },
  as: {
    app_title: "বানপানী নিৰীক্ষণ প্ৰ'",
    dashboard: "ডেশ্বব'ৰ্ড",
    map_view: "মেপ ভিউ",
    alerts: "সতৰ্কবাণী",
    analytics: "বিশ্লেষণ",
    settings: "ছেটিংছ",
    emergency: "জৰুৰীকালীন",
    flood_warning: "বানপানীৰ সতৰ্কবাণী",
    water_level_warning: "পানীৰ স্তৰৰ সতৰ্কবাণী",
    active_monitors: "সক্ৰিয় নিৰীক্ষক",
    active_alerts: "সক্ৰিয় সতৰ্কবাণী",
    people_notified: "অৱগত লোক",
    safe_zones: "নিৰাপদ অঞ্চল",
    online: "অনলাইন",
    high_priority: "উচ্চ অগ্ৰাধিকাৰ",
    last_24h: "যোৱা ২৪ ঘণ্টা",
    all_districts: "সকলো জিলা",
    real_time_water_levels: "ৰিয়েল-টাইম পানীৰ স্তৰ",
    live: "লাইভ",
    danger: "বিপদ",
    warning: "সতৰ্কবাণী",
    normal_range: "স্বাভাৱিক পৰিসৰ",
    monitoring_stations_map: "নিৰীক্ষণ কেন্দ্ৰৰ মেপ",
    real_time_status: "সকলো নিৰীক্ষণ কেন্দ্ৰৰ ৰিয়েল-টাইম অৱস্থা",
    safe_stations: "নিৰাপদ",
    warning_stations: "সতৰ্কবাণী",
    danger_stations: "বিপদ",
    water_level_trends: "পানীৰ স্তৰৰ প্ৰৱণতা",
    last_24_hours: "যোৱা ২৪ ঘণ্টা",
    last_7_days: "যোৱা ৭ দিন",
    last_30_days: "যোৱা ৩০ দিন",
    average_level: "গড় স্তৰ",
    peak_level: "সৰ্বোচ্চ স্তৰ",
    change_24h: "২ৄ ঘণ্টাৰ পৰিৱৰ্তন",
    active_alerts_panel: "সক্ৰিয় সতৰ্কবাণী",
    current_flood_warnings: "বৰ্তমান বানপানীৰ সতৰ্কবাণী",
    send_alert: "সতৰ্কবাণী পঠিয়াওক",
    monitor: "নিৰীক্ষণ",
    view: "চাওক",
    emergency_contacts: "জৰুৰীকালীন যোগাযোগ",
    quick_access_authorities: "কৰ্তৃপক্ষৰ সৈতে দ্ৰুত যোগাযোগ",
    call: "কল কৰক",
    alert_settings: "সতৰ্কবাণী ছেটিংছ",
    configure_notifications: "জাননী পছন্দ কনফিগাৰ কৰক",
    sms_alerts: "SMS সতৰ্কবাণী",
    receive_flood_warnings_sms: "SMS ৰ জৰিয়তে বানপানীৰ সতৰ্কবাণী পাওক",
    email_notifications: "ইমেইল জাননী",
    daily_summary_reports: "দৈনিক সাৰাংশ প্ৰতিবেদন",
    push_notifications: "পুশ জাননী",
    real_time_mobile_alerts: "ৰিয়েল-টাইম মোবাইল সতৰ্কবাণী",
    test_alerts: "পৰীক্ষামূলক সতৰ্কবাণী",
    map: "মেপ",
    ndrf: "NDRF",
    state_control_room: "ৰাজ্য নিয়ন্ত্ৰণ কক্ষ",
    medical_emergency: "চিকিৎসা জৰুৰীকালীন",
    weather_dept: "IMD বতৰ",
    system_update: "ছিষ্টেম আপডেট",
  },
};
