import { useState, useCallback } from "react";
import { translations, type Language, type TranslationKey } from "@/lib/translations";

export function useLanguage() {
  const [currentLanguage, setCurrentLanguage] = useState<Language>("en");

  const changeLanguage = useCallback((language: Language) => {
    setCurrentLanguage(language);
    localStorage.setItem("preferred-language", language);
  }, []);

  const t = useCallback((key: TranslationKey): string => {
    return translations[currentLanguage][key] || translations.en[key] || key;
  }, [currentLanguage]);

  // Initialize language from localStorage
  useState(() => {
    const saved = localStorage.getItem("preferred-language") as Language;
    if (saved && translations[saved]) {
      setCurrentLanguage(saved);
    }
  });

  return {
    currentLanguage,
    changeLanguage,
    t,
    availableLanguages: Object.keys(translations) as Language[],
  };
}
