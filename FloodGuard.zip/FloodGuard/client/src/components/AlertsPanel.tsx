import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/hooks/useLanguage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface AlertsPanelProps {
  alerts: any[];
}

export default function AlertsPanel({ alerts }: AlertsPanelProps) {
  const { t } = useLanguage();
  const queryClient = useQueryClient();

  const acknowledgeMutation = useMutation({
    mutationFn: (alertId: string) => 
      apiRequest("POST", `/api/alerts/${alertId}/acknowledge`, { userId: "current-user" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
  });

  const resolveMutation = useMutation({
    mutationFn: (alertId: string) =>
      apiRequest("POST", `/api/alerts/${alertId}/resolve`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
  });

  const getAlertIcon = (alertType: string, severity: string) => {
    if (alertType === "flood" || severity === "critical") {
      return "fas fa-exclamation-triangle text-destructive";
    } else if (alertType === "warning") {
      return "fas fa-exclamation-triangle text-warning";
    }
    return "fas fa-info-circle text-primary";
  };

  const getAlertBgColor = (alertType: string, severity: string) => {
    if (alertType === "flood" || severity === "critical") {
      return "border-destructive/20 bg-destructive/5";
    } else if (alertType === "warning") {
      return "border-warning/20 bg-warning/5";
    }
    return "border-primary/20 bg-primary/5";
  };

  const getAlertTitleColor = (alertType: string, severity: string) => {
    if (alertType === "flood" || severity === "critical") {
      return "text-destructive";
    } else if (alertType === "warning") {
      return "text-warning";
    }
    return "text-primary";
  };

  const getTimeAgo = (createdAt: string) => {
    const now = new Date();
    const alertTime = new Date(createdAt);
    const diffMs = now.getTime() - alertTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  };

  return (
    <Card className="shadow-sm" data-testid="alerts-panel">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold">{t("active_alerts_panel")}</CardTitle>
        <p className="text-sm text-muted-foreground">{t("current_flood_warnings")}</p>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        {alerts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="no-alerts-message">
            No active alerts
          </div>
        ) : (
          alerts.map((alert) => (
            <div 
              key={alert.id}
              className={`border rounded-lg p-4 ${getAlertBgColor(alert.alertType, alert.severity)}`}
              data-testid={`alert-item-${alert.id}`}
            >
              <div className="flex items-start space-x-3">
                <i className={`${getAlertIcon(alert.alertType, alert.severity)} mt-1`} data-testid="alert-icon"></i>
                <div className="flex-1">
                  <h3 className={`font-medium ${getAlertTitleColor(alert.alertType, alert.severity)}`} data-testid="alert-title">
                    {alert.title}
                  </h3>
                  <p className="text-sm text-foreground mt-1" data-testid="alert-message">
                    {alert.message}
                  </p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-muted-foreground" data-testid="alert-time">
                      {getTimeAgo(alert.createdAt)}
                    </span>
                    <div className="flex space-x-2">
                      {!alert.acknowledgedBy && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => acknowledgeMutation.mutate(alert.id)}
                          disabled={acknowledgeMutation.isPending}
                          data-testid={`acknowledge-button-${alert.id}`}
                        >
                          Acknowledge
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant={alert.alertType === "flood" ? "destructive" : alert.alertType === "warning" ? "default" : "default"}
                        onClick={() => resolveMutation.mutate(alert.id)}
                        disabled={resolveMutation.isPending}
                        data-testid={`action-button-${alert.id}`}
                      >
                        {alert.alertType === "flood" ? t("send_alert") : 
                         alert.alertType === "warning" ? t("monitor") : 
                         t("view")}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
