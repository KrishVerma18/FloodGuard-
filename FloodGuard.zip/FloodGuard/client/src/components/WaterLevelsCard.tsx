import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/useLanguage";

interface WaterLevelsCardProps {
  readings: any[];
  stations: any[];
}

export default function WaterLevelsCard({ readings, stations }: WaterLevelsCardProps) {
  const { t } = useLanguage();

  const getStationStatus = (reading: any, station: any) => {
    if (!reading || !station) return "safe";
    
    if (reading.waterLevel >= station.dangerLevel) return "danger";
    if (reading.waterLevel >= station.warningLevel) return "warning";
    return "safe";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "danger": return "destructive";
      case "warning": return "warning";
      default: return "success";
    }
  };

  const getStatusText = (status: string, station: any) => {
    switch (status) {
      case "danger": return `${t("danger")}: ${station?.dangerLevel}m`;
      case "warning": return `${t("warning")}: ${station?.warningLevel}m`;
      default: return t("normal_range");
    }
  };

  const combinedData = readings.map(reading => {
    const station = stations.find(s => s.stationId === reading.stationId);
    const status = getStationStatus(reading, station);
    return { reading, station, status };
  }).filter(item => item.station);

  return (
    <Card className="shadow-sm" data-testid="water-levels-card">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{t("real_time_water_levels")}</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse" data-testid="live-indicator"></div>
            <span className="text-sm text-muted-foreground">{t("live")}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {combinedData.map(({ reading, station, status }) => (
            <div 
              key={reading.stationId}
              className={`flex items-center justify-between p-4 border rounded-lg ${
                status === "danger" ? "bg-destructive/5 border-destructive/20" :
                status === "warning" ? "bg-warning/5 border-warning/20" :
                "bg-success/5 border-success/20"
              }`}
              data-testid={`water-level-${reading.stationId}`}
            >
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${
                  status === "danger" ? "bg-destructive" :
                  status === "warning" ? "bg-warning" :
                  "bg-success"
                } ${status === "danger" ? "pulse-danger" : ""}`}></div>
                <div>
                  <h3 className="font-medium text-foreground" data-testid="station-name">
                    {station.name}
                  </h3>
                  <p className="text-sm text-muted-foreground" data-testid="station-id">
                    Station ID: {station.stationId}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-lg font-bold ${
                  status === "danger" ? "text-destructive" :
                  status === "warning" ? "text-warning" :
                  "text-success"
                }`} data-testid="water-level">
                  {reading.waterLevel}m
                </p>
                <p className="text-sm text-muted-foreground" data-testid="status-text">
                  {getStatusText(status, station)}
                </p>
              </div>
            </div>
          ))}
          
          {combinedData.length === 0 && (
            <div className="text-center py-8 text-muted-foreground" data-testid="no-data-message">
              No water level data available
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
