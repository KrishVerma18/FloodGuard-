import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/hooks/useLanguage";

export default function EmergencyContacts() {
  const { t } = useLanguage();

  const { data: contacts, isLoading } = useQuery({
    queryKey: ["/api/emergency-contacts"],
  });

  const handleCall = (contact: any) => {
    // In a real implementation, this would initiate a phone call
    // For now, we'll show the phone number
    if (navigator.userAgent.match(/Mobile|Android|iPhone/)) {
      window.location.href = `tel:${contact.phone}`;
    } else {
      alert(`Call ${contact.name} at ${contact.phone}`);
    }
  };

  const getContactIcon = (contactType: string) => {
    switch (contactType) {
      case "ndrf":
        return "fas fa-phone";
      case "state_control":
        return "fas fa-shield-alt";
      case "medical":
        return "fas fa-hospital";
      case "weather":
        return "fas fa-broadcast-tower";
      default:
        return "fas fa-phone";
    }
  };

  const getContactColor = (contactType: string) => {
    switch (contactType) {
      case "ndrf":
        return "bg-destructive";
      case "state_control":
        return "bg-primary";
      case "medical":
        return "bg-success";
      case "weather":
        return "bg-warning";
      default:
        return "bg-muted";
    }
  };

  const getContactName = (contactType: string) => {
    switch (contactType) {
      case "ndrf":
        return t("ndrf");
      case "state_control":
        return t("state_control_room");
      case "medical":
        return t("medical_emergency");
      case "weather":
        return t("weather_dept");
      default:
        return contactType;
    }
  };

  if (isLoading) {
    return (
      <Card className="shadow-sm" data-testid="emergency-contacts">
        <CardHeader className="border-b border-border">
          <CardTitle className="text-lg font-semibold">{t("emergency_contacts")}</CardTitle>
          <p className="text-sm text-muted-foreground">{t("quick_access_authorities")}</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-muted rounded-lg animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-muted-foreground/20 rounded-full"></div>
                  <div className="space-y-1">
                    <div className="w-24 h-4 bg-muted-foreground/20 rounded"></div>
                    <div className="w-32 h-3 bg-muted-foreground/20 rounded"></div>
                  </div>
                </div>
                <div className="w-12 h-6 bg-muted-foreground/20 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm" data-testid="emergency-contacts">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold">{t("emergency_contacts")}</CardTitle>
        <p className="text-sm text-muted-foreground">{t("quick_access_authorities")}</p>
      </CardHeader>
      <CardContent className="p-6 space-y-3">
        {contacts && Array.isArray(contacts) && contacts.length > 0 ? (
          (contacts as any[]).map((contact: any) => (
            <div 
              key={contact.id}
              className="flex items-center justify-between p-3 bg-muted rounded-lg hover:bg-muted/80 transition-colors"
              data-testid={`emergency-contact-${contact.contactType}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 ${getContactColor(contact.contactType)} rounded-full flex items-center justify-center`}>
                  <i className={`${getContactIcon(contact.contactType)} text-white text-sm`} data-testid="contact-icon"></i>
                </div>
                <div>
                  <p className="font-medium text-foreground" data-testid="contact-name">
                    {getContactName(contact.contactType)}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid="contact-org">
                    {contact.organization}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className={`font-medium text-sm ${
                  contact.contactType === "ndrf" ? "text-destructive hover:text-destructive/80" :
                  contact.contactType === "state_control" ? "text-primary hover:text-primary/80" :
                  contact.contactType === "medical" ? "text-success hover:text-success/80" :
                  "text-warning hover:text-warning/80"
                }`}
                onClick={() => handleCall(contact)}
                data-testid={`call-button-${contact.contactType}`}
              >
                {t("call")}
              </Button>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-muted-foreground" data-testid="no-contacts-message">
            No emergency contacts available
          </div>
        )}
      </CardContent>
    </Card>
  );
}
