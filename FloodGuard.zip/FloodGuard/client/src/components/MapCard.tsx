import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/useLanguage";

interface MapCardProps {
  stations: any[];
  readings: any[];
  breakdown?: {
    safe: number;
    warning: number;
    danger: number;
  };
}

export default function MapCard({ stations, readings, breakdown }: MapCardProps) {
  const { t } = useLanguage();

  const getStationStatus = (stationId: string) => {
    const reading = readings.find(r => r.stationId === stationId);
    const station = stations.find(s => s.stationId === stationId);
    
    if (!reading || !station) return "safe";
    
    if (reading.waterLevel >= station.dangerLevel) return "danger";
    if (reading.waterLevel >= station.warningLevel) return "warning";
    return "safe";
  };

  const getStationData = (stationId: string) => {
    const reading = readings.find(r => r.stationId === stationId);
    const station = stations.find(s => s.stationId === stationId);
    return { reading, station };
  };

  return (
    <Card className="shadow-sm" data-testid="map-card">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold">{t("monitoring_stations_map")}</CardTitle>
        <p className="text-sm text-muted-foreground">{t("real_time_status")}</p>
      </CardHeader>
      <CardContent className="p-6">
        {/* Simulated India map with monitoring stations */}
        <div className="relative h-96 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg overflow-hidden" data-testid="map-container">
          {/* India map background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-green-100 opacity-50"></div>
          
          {/* Monitoring station markers */}
          {stations.map((station) => {
            const status = getStationStatus(station.stationId);
            const { reading } = getStationData(station.stationId);
            
            // Position stations based on rough coordinates
            let position: React.CSSProperties = { top: "50%", left: "50%" };
            if (station.stationId === "BR-001") {
              position = { top: "16%", right: "20%" };
            } else if (station.stationId === "GN-002") {
              position = { top: "32%", left: "33%" };
            } else if (station.stationId === "YM-003") {
              position = { top: "24%", left: "25%" };
            } else if (station.stationId === "PR-004") {
              position = { bottom: "20%", left: "16%" };
            }

            return (
              <div 
                key={station.stationId}
                className="absolute transform -translate-x-1/2 -translate-y-1/2"
                style={position}
                data-testid={`station-marker-${station.stationId}`}
              >
                <div className={`w-4 h-4 rounded-full shadow-lg ${
                  status === "danger" ? "bg-destructive pulse-danger" :
                  status === "warning" ? "bg-warning" :
                  "bg-success"
                }`}></div>
                {reading && (
                  <div className={`absolute -top-8 left-1/2 transform -translate-x-1/2 px-2 py-1 rounded text-xs whitespace-nowrap text-white ${
                    status === "danger" ? "bg-destructive" :
                    status === "warning" ? "bg-warning" :
                    "bg-success"
                  }`} data-testid={`station-tooltip-${station.stationId}`}>
                    {station.location}: {reading.waterLevel}m
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Map Legend */}
        <div className="flex items-center justify-center space-x-6 mt-4 p-4 bg-muted rounded-lg" data-testid="map-legend">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-success rounded-full"></div>
            <span className="text-sm text-muted-foreground">
              {t("safe_stations")} ({breakdown?.safe || 0} stations)
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-warning rounded-full"></div>
            <span className="text-sm text-muted-foreground">
              {t("warning_stations")} ({breakdown?.warning || 0} stations)
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-destructive rounded-full"></div>
            <span className="text-sm text-muted-foreground">
              {t("danger_stations")} ({breakdown?.danger || 0} stations)
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
