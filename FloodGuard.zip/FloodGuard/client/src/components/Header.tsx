import { useLanguage } from "@/hooks/useLanguage";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Header() {
  const { t, currentLanguage, changeLanguage, availableLanguages } = useLanguage();

  const languageNames = {
    en: "English",
    hi: "हिंदी",
    bn: "বাংলা", 
    as: "অসমীয়া"
  };

  return (
    <header className="bg-card border-b border-border shadow-sm" data-testid="header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <i className="fas fa-water text-primary text-2xl" data-testid="logo-icon"></i>
              <h1 className="text-xl font-bold text-foreground" data-testid="app-title">{t("app_title")}</h1>
            </div>
            {/* Critical Alert Banner */}
            <div className="hidden md:flex items-center space-x-2 bg-destructive/10 text-destructive px-3 py-1 rounded-md pulse-danger">
              <i className="fas fa-exclamation-triangle"></i>
              <span className="text-sm font-medium" data-testid="alert-count">2 Active Flood Warnings</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Language Selector */}
            <Select value={currentLanguage} onValueChange={changeLanguage}>
              <SelectTrigger className="w-32" data-testid="language-selector">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableLanguages.map((lang) => (
                  <SelectItem key={lang} value={lang} data-testid={`language-option-${lang}`}>
                    {languageNames[lang]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {/* Emergency Button */}
            <Button variant="destructive" className="font-medium" data-testid="emergency-button">
              <i className="fas fa-phone mr-2"></i>
              {t("emergency")}
            </Button>
            
            {/* User Profile */}
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center" data-testid="user-avatar">
                <i className="fas fa-user text-primary-foreground text-sm"></i>
              </div>
              <span className="hidden md:block text-sm font-medium" data-testid="user-name">Admin User</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
