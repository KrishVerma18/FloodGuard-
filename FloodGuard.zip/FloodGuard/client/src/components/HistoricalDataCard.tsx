import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/hooks/useLanguage";
import { useState } from "react";

interface HistoricalDataCardProps {
  stationId: string;
}

export default function HistoricalDataCard({ stationId }: HistoricalDataCardProps) {
  const { t } = useLanguage();
  const [timeRange, setTimeRange] = useState("24h");

  const { data: readings } = useQuery({
    queryKey: ["/api/readings", stationId, { limit: timeRange === "24h" ? 24 : timeRange === "7d" ? 168 : 720 }],
  });

  const { data: station } = useQuery({
    queryKey: ["/api/stations"],
    select: (data: any[]) => data?.find((s: any) => s.stationId === stationId),
  });

  const calculateStats = () => {
    if (!readings || !Array.isArray(readings) || readings.length === 0) {
      return { average: 0, peak: 0, change: 0 };
    }

    const levels = (readings as any[]).map((r: any) => r.waterLevel);
    const average = levels.reduce((sum: number, level: number) => sum + level, 0) / levels.length;
    const peak = Math.max(...levels);
    const change = (readings as any[]).length > 1 ? (readings as any[])[0].waterLevel - (readings as any[])[(readings as any[]).length - 1].waterLevel : 0;

    return {
      average: Math.round(average * 10) / 10,
      peak: Math.round(peak * 10) / 10,
      change: Math.round(change * 10) / 10,
    };
  };

  const stats = calculateStats();

  return (
    <Card className="shadow-sm" data-testid="historical-data-card">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{t("water_level_trends")}</CardTitle>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40" data-testid="time-range-selector">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">{t("last_24_hours")}</SelectItem>
              <SelectItem value="7d">{t("last_7_days")}</SelectItem>
              <SelectItem value="30d">{t("last_30_days")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="chart-container relative bg-gradient-to-t from-primary/10 to-transparent rounded-lg" data-testid="chart-container">
          {/* Simulated chart visualization */}
          <div className="absolute inset-0 flex items-end justify-around p-4">
            {readings && Array.isArray(readings) && (readings as any[]).slice(0, 8).map((reading: any, index: number) => {
              const height = station ? 
                Math.min((reading.waterLevel / (station.dangerLevel * 1.2)) * 100, 100) : 
                Math.random() * 80 + 20;
              
              let color = "bg-success";
              if (station) {
                if (reading.waterLevel >= station.dangerLevel) color = "bg-destructive";
                else if (reading.waterLevel >= station.warningLevel) color = "bg-warning";
              }

              return (
                <div 
                  key={index}
                  className={`w-2 ${color}`}
                  style={{ height: `${height}%` }}
                  data-testid={`chart-bar-${index}`}
                ></div>
              );
            })}
          </div>
          
          {station && (
            <>
              {/* Danger line */}
              <div 
                className="absolute left-0 right-0 bg-destructive/50 h-0.5" 
                style={{ bottom: `${(station.dangerLevel / (station.dangerLevel * 1.2)) * 100}%` }}
                data-testid="danger-line"
              ></div>
              <div 
                className="absolute right-4 text-xs text-destructive" 
                style={{ bottom: `${(station.dangerLevel / (station.dangerLevel * 1.2)) * 100 + 2}%` }}
              >
                Danger Level
              </div>
              
              {/* Warning line */}
              <div 
                className="absolute left-0 right-0 bg-warning/50 h-0.5" 
                style={{ bottom: `${(station.warningLevel / (station.dangerLevel * 1.2)) * 100}%` }}
                data-testid="warning-line"
              ></div>
              <div 
                className="absolute right-4 text-xs text-warning" 
                style={{ bottom: `${(station.warningLevel / (station.dangerLevel * 1.2)) * 100 + 2}%` }}
              >
                Warning Level
              </div>
            </>
          )}
        </div>
        
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div data-testid="average-level">
            <p className="text-2xl font-bold text-success">{stats.average}m</p>
            <p className="text-sm text-muted-foreground">{t("average_level")}</p>
          </div>
          <div data-testid="peak-level">
            <p className="text-2xl font-bold text-destructive">{stats.peak}m</p>
            <p className="text-sm text-muted-foreground">{t("peak_level")}</p>
          </div>
          <div data-testid="change-24h">
            <p className={`text-2xl font-bold ${stats.change > 0 ? "text-primary" : "text-destructive"}`}>
              {stats.change > 0 ? "↑" : "↓"} {Math.abs(stats.change)}m
            </p>
            <p className="text-sm text-muted-foreground">{t("change_24h")}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
