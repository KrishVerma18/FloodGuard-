import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle: string;
  icon: string;
  variant: "primary" | "destructive" | "success" | "warning";
  trend?: "up" | "down" | "warning";
}

export default function StatsCard({ title, value, subtitle, icon, variant, trend }: StatsCardProps) {
  const variantClasses = {
    primary: "bg-primary/10 text-primary",
    destructive: "bg-destructive/10 text-destructive",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
  };

  const trendClasses = {
    up: "text-success",
    down: "text-destructive",
    warning: "text-warning",
  };

  const trendIcons = {
    up: "fas fa-arrow-up",
    down: "fas fa-arrow-down", 
    warning: "fas fa-exclamation-triangle",
  };

  return (
    <Card className="shadow-sm" data-testid={`stats-card-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm font-medium" data-testid="stats-title">{title}</p>
            <p className="text-3xl font-bold text-foreground" data-testid="stats-value">{value}</p>
            {trend && (
              <p className={`text-sm ${trendClasses[trend]}`} data-testid="stats-subtitle">
                <i className={`${trendIcons[trend]} mr-1`}></i>{subtitle}
              </p>
            )}
            {!trend && (
              <p className="text-sm text-muted-foreground" data-testid="stats-subtitle">{subtitle}</p>
            )}
          </div>
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${variantClasses[variant]}`} data-testid="stats-icon">
            <i className={`${icon} text-xl`}></i>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
