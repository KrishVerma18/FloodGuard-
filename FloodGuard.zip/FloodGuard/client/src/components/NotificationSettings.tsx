import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useLanguage } from "@/hooks/useLanguage";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function NotificationSettings() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    sms: true,
    email: true,
    push: false,
  });

  const testNotificationMutation = useMutation({
    mutationFn: (data: { method: string; recipient: string }) =>
      apiRequest("POST", "/api/notifications/test", data),
    onSuccess: (response) => {
      toast({
        title: "Test Alert Sent",
        description: "Test notification has been sent successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send test notification. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSettingChange = (setting: keyof typeof settings, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value,
    }));
    
    // In a real implementation, this would save to the backend
    console.log(`Updated ${setting} setting to:`, value);
  };

  const handleTestAlerts = () => {
    // Send test notifications based on enabled settings
    if (settings.sms) {
      testNotificationMutation.mutate({
        method: "sms",
        recipient: "+1234567890", // In real app, this would be user's phone
      });
    }
    
    if (settings.email) {
      testNotificationMutation.mutate({
        method: "email",
        recipient: "user@example.com", // In real app, this would be user's email
      });
    }

    if (!settings.sms && !settings.email) {
      toast({
        title: "No Notifications Enabled",
        description: "Please enable at least one notification method to test alerts.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="shadow-sm" data-testid="notification-settings">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-lg font-semibold">{t("alert_settings")}</CardTitle>
        <p className="text-sm text-muted-foreground">{t("configure_notifications")}</p>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center justify-between" data-testid="sms-setting">
          <div>
            <p className="font-medium text-foreground">{t("sms_alerts")}</p>
            <p className="text-sm text-muted-foreground">{t("receive_flood_warnings_sms")}</p>
          </div>
          <Switch
            checked={settings.sms}
            onCheckedChange={(checked) => handleSettingChange("sms", checked)}
            data-testid="sms-toggle"
          />
        </div>

        <div className="flex items-center justify-between" data-testid="email-setting">
          <div>
            <p className="font-medium text-foreground">{t("email_notifications")}</p>
            <p className="text-sm text-muted-foreground">{t("daily_summary_reports")}</p>
          </div>
          <Switch
            checked={settings.email}
            onCheckedChange={(checked) => handleSettingChange("email", checked)}
            data-testid="email-toggle"
          />
        </div>

        <div className="flex items-center justify-between" data-testid="push-setting">
          <div>
            <p className="font-medium text-foreground">{t("push_notifications")}</p>
            <p className="text-sm text-muted-foreground">{t("real_time_mobile_alerts")}</p>
          </div>
          <Switch
            checked={settings.push}
            onCheckedChange={(checked) => handleSettingChange("push", checked)}
            data-testid="push-toggle"
          />
        </div>

        <div className="pt-4 border-t border-border">
          <Button 
            className="w-full"
            onClick={handleTestAlerts}
            disabled={testNotificationMutation.isPending}
            data-testid="test-alerts-button"
          >
            <i className="fas fa-paper-plane mr-2"></i>
            {testNotificationMutation.isPending ? "Sending..." : t("test_alerts")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
