import { Button } from "@/components/ui/button";

interface AlertBannerProps {
  alerts: any[];
}

export default function AlertBanner({ alerts }: AlertBannerProps) {
  if (!alerts || alerts.length === 0) return null;

  const primaryAlert = alerts[0];

  return (
    <div className="bg-destructive text-destructive-foreground px-4 py-3" data-testid="alert-banner">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <i className="fas fa-exclamation-triangle text-lg pulse-danger" data-testid="alert-icon"></i>
          <div>
            <p className="font-semibold" data-testid="alert-title">{primaryAlert.title}</p>
            <p className="text-sm opacity-90" data-testid="alert-message">
              {primaryAlert.message.substring(0, 100)}...
              {primaryAlert.createdAt && ` • Last updated: ${new Date(primaryAlert.createdAt).toLocaleTimeString()}`}
            </p>
          </div>
        </div>
        <Button 
          variant="secondary" 
          size="sm" 
          className="bg-white/20 hover:bg-white/30"
          data-testid="alert-details-button"
        >
          View Details
        </Button>
      </div>
    </div>
  );
}
