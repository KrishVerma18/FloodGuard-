import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";

export default function MobileNav() {
  const [location, setLocation] = useLocation();
  const { t } = useLanguage();

  const isActive = (path: string) => location === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border md:hidden" data-testid="mobile-nav">
      <div className="grid grid-cols-5 gap-1">
        <button 
          className={`flex flex-col items-center py-2 ${isActive("/") ? "text-primary" : "text-muted-foreground"}`}
          onClick={() => setLocation("/")}
          data-testid="mobile-nav-dashboard"
        >
          <i className="fas fa-tachometer-alt text-lg"></i>
          <span className="text-xs mt-1">{t("dashboard")}</span>
        </button>
        
        <button 
          className={`flex flex-col items-center py-2 ${isActive("/map") ? "text-primary" : "text-muted-foreground"}`}
          onClick={() => setLocation("/map")}
          data-testid="mobile-nav-map"
        >
          <i className="fas fa-map text-lg"></i>
          <span className="text-xs mt-1">{t("map")}</span>
        </button>
        
        <button 
          className={`flex flex-col items-center py-2 relative ${isActive("/alerts") ? "text-primary" : "text-muted-foreground"}`}
          onClick={() => setLocation("/alerts")}
          data-testid="mobile-nav-alerts"
        >
          <i className="fas fa-bell text-lg"></i>
          <span className="text-xs mt-1">{t("alerts")}</span>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full" data-testid="alert-badge"></div>
        </button>
        
        <button 
          className={`flex flex-col items-center py-2 ${isActive("/analytics") ? "text-primary" : "text-muted-foreground"}`}
          onClick={() => setLocation("/analytics")}
          data-testid="mobile-nav-analytics"
        >
          <i className="fas fa-chart-line text-lg"></i>
          <span className="text-xs mt-1">{t("analytics")}</span>
        </button>
        
        <button 
          className={`flex flex-col items-center py-2 ${isActive("/settings") ? "text-primary" : "text-muted-foreground"}`}
          onClick={() => setLocation("/settings")}
          data-testid="mobile-nav-settings"
        >
          <i className="fas fa-cog text-lg"></i>
          <span className="text-xs mt-1">{t("settings")}</span>
        </button>
      </div>
    </div>
  );
}
