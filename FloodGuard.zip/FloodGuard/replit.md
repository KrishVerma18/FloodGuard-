# Overview

This is a comprehensive flood monitoring and alert system built to provide real-time water level monitoring for rivers across India. The application serves as an early warning system for flood conditions, featuring real-time data visualization, automated alert generation, and multi-language support for regional accessibility. The system monitors water levels at various river stations and sends notifications when dangerous thresholds are exceeded.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using modern React with TypeScript, implementing a single-page application (SPA) architecture:

- **Framework**: React 18 with TypeScript for type safety and developer experience
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for accessible, customizable components
- **Styling**: Tailwind CSS with CSS variables for theming support
- **Build Tool**: Vite for fast development and optimized production builds

The application follows a component-based architecture with clear separation between UI components, business logic, and data fetching. The dashboard provides real-time monitoring capabilities with WebSocket integration for live updates.

## Backend Architecture

The backend implements a REST API with real-time capabilities:

- **Framework**: Express.js with TypeScript for the HTTP server
- **Real-time Communication**: WebSocket server for live data streaming to connected clients
- **Data Simulation**: IoT simulator service that generates realistic water level readings for demonstration
- **Alert System**: Automated alert generation based on configurable water level thresholds
- **Notification Services**: Multi-channel notification system supporting SMS, email, and push notifications

The server architecture uses a service-oriented approach with separate modules for alert processing, IoT simulation, and notification handling. The storage layer is abstracted through an interface, allowing for flexible data persistence strategies.

## Data Storage Solutions

The application uses a hybrid storage approach:

- **Database**: PostgreSQL as the primary database with Drizzle ORM for type-safe database operations
- **Schema Design**: Comprehensive schema supporting users, monitoring stations, water level readings, alerts, emergency contacts, and notification logs
- **Cloud Database**: Neon serverless PostgreSQL for scalable, managed database hosting
- **In-Memory Storage**: Fallback memory storage implementation for development and testing scenarios

The database schema is designed to handle time-series data efficiently with proper indexing for real-time queries and historical data analysis.

## Authentication and Authorization

The system implements a role-based access control model:

- **User Roles**: Support for different user types (user, admin, authority)
- **Session Management**: PostgreSQL-based session storage using connect-pg-simple
- **Multi-language Support**: User preferences stored in database including language and notification settings
- **Regional Access**: Location-based access controls for relevant monitoring stations

## External Service Integrations

The application integrates with multiple external services for comprehensive functionality:

- **Twilio**: SMS notification service for critical flood alerts
- **SMTP Services**: Email notifications through configurable SMTP providers
- **Google Fonts**: Custom typography with multiple font families for better readability
- **Neon Database**: Serverless PostgreSQL hosting for production deployments

The notification system is designed to handle high-volume alert scenarios with proper rate limiting and delivery tracking. The architecture supports easy integration of additional notification channels and external weather/hydrological data sources.

# External Dependencies

- **Database**: PostgreSQL via Neon serverless platform for scalable data storage
- **Real-time Communication**: Native WebSocket implementation for live data streaming
- **SMS Service**: Twilio API integration for emergency notifications
- **Email Service**: SMTP-based email delivery system
- **UI Framework**: Radix UI components with shadcn/ui styling system
- **State Management**: TanStack Query for efficient data fetching and caching
- **Styling**: Tailwind CSS with PostCSS for modern, responsive design
- **Development Tools**: Vite build system with TypeScript support
- **Database ORM**: Drizzle ORM with Zod validation for type-safe database operations