import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { iotSimulator } from "./services/iotSimulator";
import { alertService } from "./services/alertService";
import { notificationService } from "./services/notificationService";

interface WebSocketMessage {
  type: string;
  data: any;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store connected clients
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('message', async (message) => {
      try {
        const parsed: WebSocketMessage = JSON.parse(message.toString());
        await handleWebSocketMessage(ws, parsed);
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });

    // Send initial data
    const sendInitialData = async () => {
      const initialData = {
        stations: await storage.getMonitoringStations(),
        latestReadings: await storage.getLatestReadings(),
        alerts: await alertService.getActiveAlerts(),
      };
      sendToClient(ws, 'initial_data', initialData);
    };
    sendInitialData();
  });

  // Broadcast to all connected clients
  function broadcast(type: string, data: any) {
    const message = JSON.stringify({ type, data });
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Send to specific client
  function sendToClient(client: WebSocket, type: string, data: any) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type, data }));
    }
  }

  async function handleWebSocketMessage(ws: WebSocket, message: WebSocketMessage) {
    switch (message.type) {
      case 'get_stations':
        sendToClient(ws, 'stations', await storage.getMonitoringStations());
        break;
      case 'get_readings':
        sendToClient(ws, 'readings', await storage.getLatestReadings());
        break;
      case 'get_alerts':
        sendToClient(ws, 'alerts', await alertService.getActiveAlerts());
        break;
    }
  }

  // Start IoT simulation and generate initial data
  await iotSimulator.generateInitialReadings();
  iotSimulator.startSimulation();

  // Monitor new readings for alerts
  setInterval(async () => {
    const latestReadings = await storage.getLatestReadings();
    
    // Process each reading for potential alerts
    for (const reading of latestReadings) {
      await alertService.processWaterLevelReading(reading);
    }

    // Broadcast latest data to all clients
    broadcast('readings_update', latestReadings);
    broadcast('alerts_update', await alertService.getActiveAlerts());
  }, 30000); // Every 30 seconds

  // API Routes

  // Get all monitoring stations
  app.get('/api/stations', async (req, res) => {
    try {
      const stations = await storage.getMonitoringStations();
      res.json(stations);
    } catch (error) {
      console.error('Error fetching stations:', error);
      res.status(500).json({ message: 'Failed to fetch monitoring stations' });
    }
  });

  // Get water level readings
  app.get('/api/readings', async (req, res) => {
    try {
      const { stationId, limit } = req.query;
      const readings = await storage.getWaterLevelReadings(
        stationId as string,
        limit ? parseInt(limit as string) : undefined
      );
      res.json(readings);
    } catch (error) {
      console.error('Error fetching readings:', error);
      res.status(500).json({ message: 'Failed to fetch water level readings' });
    }
  });

  // Get latest readings for all stations
  app.get('/api/readings/latest', async (req, res) => {
    try {
      const readings = await storage.getLatestReadings();
      res.json(readings);
    } catch (error) {
      console.error('Error fetching latest readings:', error);
      res.status(500).json({ message: 'Failed to fetch latest readings' });
    }
  });

  // Get alerts
  app.get('/api/alerts', async (req, res) => {
    try {
      const { active } = req.query;
      const isActive = active === 'true' ? true : active === 'false' ? false : undefined;
      const alerts = await storage.getAlerts(isActive);
      res.json(alerts);
    } catch (error) {
      console.error('Error fetching alerts:', error);
      res.status(500).json({ message: 'Failed to fetch alerts' });
    }
  });

  // Acknowledge alert
  app.post('/api/alerts/:id/acknowledge', async (req, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;
      
      const updatedAlert = await alertService.acknowledgeAlert(id, userId || 'system');
      if (!updatedAlert) {
        return res.status(404).json({ message: 'Alert not found' });
      }
      
      broadcast('alerts_update', await alertService.getActiveAlerts());
      res.json(updatedAlert);
    } catch (error) {
      console.error('Error acknowledging alert:', error);
      res.status(500).json({ message: 'Failed to acknowledge alert' });
    }
  });

  // Resolve alert
  app.post('/api/alerts/:id/resolve', async (req, res) => {
    try {
      const { id } = req.params;
      
      const updatedAlert = await alertService.resolveAlert(id);
      if (!updatedAlert) {
        return res.status(404).json({ message: 'Alert not found' });
      }
      
      broadcast('alerts_update', await alertService.getActiveAlerts());
      res.json(updatedAlert);
    } catch (error) {
      console.error('Error resolving alert:', error);
      res.status(500).json({ message: 'Failed to resolve alert' });
    }
  });

  // Get emergency contacts
  app.get('/api/emergency-contacts', async (req, res) => {
    try {
      const { state } = req.query;
      const contacts = await storage.getEmergencyContacts(state as string);
      res.json(contacts);
    } catch (error) {
      console.error('Error fetching emergency contacts:', error);
      res.status(500).json({ message: 'Failed to fetch emergency contacts' });
    }
  });

  // Send test notification
  app.post('/api/notifications/test', async (req, res) => {
    try {
      const { method, recipient } = req.body;
      
      if (!method || !recipient) {
        return res.status(400).json({ message: 'Method and recipient are required' });
      }
      
      const result = await notificationService.sendTestNotification(method, recipient);
      res.json(result);
    } catch (error) {
      console.error('Error sending test notification:', error);
      res.status(500).json({ message: 'Failed to send test notification' });
    }
  });

  // Get notification logs
  app.get('/api/notifications/logs', async (req, res) => {
    try {
      const { alertId } = req.query;
      const logs = await storage.getNotificationLogs(alertId as string);
      res.json(logs);
    } catch (error) {
      console.error('Error fetching notification logs:', error);
      res.status(500).json({ message: 'Failed to fetch notification logs' });
    }
  });

  // Dashboard statistics
  app.get('/api/dashboard/stats', async (req, res) => {
    try {
      const stations = await storage.getMonitoringStations();
      const activeStations = stations.filter(s => s.isActive);
      const activeAlerts = await storage.getAlerts(true);
      const latestReadings = await storage.getLatestReadings();
      
      // Calculate people notified (simulated)
      const notificationLogs = await storage.getNotificationLogs();
      const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const recent24hNotifications = notificationLogs.filter(log => 
        new Date(log.sentAt) > last24h && log.status === 'sent'
      );
      
      // Calculate safe zones percentage
      const dangerStations = latestReadings.filter(reading => {
        const station = stations.find(s => s.stationId === reading.stationId);
        return station && reading.waterLevel >= station.dangerLevel;
      });
      const warningStations = latestReadings.filter(reading => {
        const station = stations.find(s => s.stationId === reading.stationId);
        return station && reading.waterLevel >= station.warningLevel && reading.waterLevel < station.dangerLevel;
      });
      
      const safeZonePercentage = Math.round(
        ((latestReadings.length - dangerStations.length - warningStations.length) / latestReadings.length) * 100
      );

      const stats = {
        activeMonitors: activeStations.length,
        monitorUptime: Math.round((activeStations.length / stations.length) * 100 * 10) / 10,
        activeAlerts: activeAlerts.filter(a => a.severity === 'critical' || a.severity === 'high').length,
        peopleNotified: recent24hNotifications.length * 100, // Simulated multiplier
        safeZonePercentage,
        stationBreakdown: {
          safe: latestReadings.length - dangerStations.length - warningStations.length,
          warning: warningStations.length,
          danger: dangerStations.length,
        }
      };
      
      res.json(stats);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      res.status(500).json({ message: 'Failed to fetch dashboard statistics' });
    }
  });

  return httpServer;
}
