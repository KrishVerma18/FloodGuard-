import { 
  type User, type InsertUser,
  type MonitoringStation, type InsertMonitoringStation,
  type WaterLevelReading, type InsertWaterLevelReading,
  type Alert, type InsertAlert,
  type EmergencyContact, type InsertEmergencyContact,
  type NotificationLog, type InsertNotificationLog
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Monitoring Stations
  getMonitoringStations(): Promise<MonitoringStation[]>;
  getMonitoringStation(stationId: string): Promise<MonitoringStation | undefined>;
  createMonitoringStation(station: InsertMonitoringStation): Promise<MonitoringStation>;
  updateMonitoringStation(stationId: string, updates: Partial<MonitoringStation>): Promise<MonitoringStation | undefined>;

  // Water Level Readings
  getWaterLevelReadings(stationId?: string, limit?: number): Promise<WaterLevelReading[]>;
  createWaterLevelReading(reading: InsertWaterLevelReading): Promise<WaterLevelReading>;
  getLatestReadings(): Promise<WaterLevelReading[]>;

  // Alerts
  getAlerts(isActive?: boolean): Promise<Alert[]>;
  getAlert(id: string): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, updates: Partial<Alert>): Promise<Alert | undefined>;
  getActiveAlertsByStation(stationId: string): Promise<Alert[]>;

  // Emergency Contacts
  getEmergencyContacts(state?: string): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;

  // Notification Logs
  createNotificationLog(log: InsertNotificationLog): Promise<NotificationLog>;
  getNotificationLogs(alertId?: string): Promise<NotificationLog[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private monitoringStations: Map<string, MonitoringStation> = new Map();
  private waterLevelReadings: WaterLevelReading[] = [];
  private alerts: Map<string, Alert> = new Map();
  private emergencyContacts: Map<string, EmergencyContact> = new Map();
  private notificationLogs: NotificationLog[] = [];

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize monitoring stations
    const stations: MonitoringStation[] = [
      {
        id: randomUUID(),
        name: "Brahmaputra - Dibrugarh",
        stationId: "BR-001",
        riverName: "Brahmaputra",
        location: "Dibrugarh",
        state: "Assam",
        latitude: 27.4728,
        longitude: 94.9120,
        normalLevel: 40.0,
        warningLevel: 42.5,
        dangerLevel: 44.0,
        isActive: true,
        lastMaintenance: new Date("2024-08-15"),
        createdAt: new Date("2024-01-01"),
      },
      {
        id: randomUUID(),
        name: "Ganga - Patna",
        stationId: "GN-002",
        riverName: "Ganga",
        location: "Patna",
        state: "Bihar",
        latitude: 25.5941,
        longitude: 85.1376,
        normalLevel: 40.0,
        warningLevel: 42.5,
        dangerLevel: 43.0,
        isActive: true,
        lastMaintenance: new Date("2024-08-20"),
        createdAt: new Date("2024-01-01"),
      },
      {
        id: randomUUID(),
        name: "Yamuna - Delhi",
        stationId: "YM-003",
        riverName: "Yamuna",
        location: "Delhi",
        state: "Delhi",
        latitude: 28.7041,
        longitude: 77.1025,
        normalLevel: 200.0,
        warningLevel: 204.5,
        dangerLevel: 206.0,
        isActive: true,
        lastMaintenance: new Date("2024-08-10"),
        createdAt: new Date("2024-01-01"),
      },
      {
        id: randomUUID(),
        name: "Periyar - Kochi",
        stationId: "PR-004",
        riverName: "Periyar",
        location: "Kochi",
        state: "Kerala",
        latitude: 9.9312,
        longitude: 76.2673,
        normalLevel: 3.0,
        warningLevel: 4.5,
        dangerLevel: 5.0,
        isActive: true,
        lastMaintenance: new Date("2024-08-25"),
        createdAt: new Date("2024-01-01"),
      },
    ];

    stations.forEach(station => {
      this.monitoringStations.set(station.stationId, station);
    });

    // Initialize emergency contacts
    const contacts: EmergencyContact[] = [
      {
        id: randomUUID(),
        name: "NDRF",
        organization: "National Disaster Response Force",
        phone: "1078",
        email: "ndrf@gov.in",
        contactType: "ndrf",
        state: "National",
        isActive: true,
      },
      {
        id: randomUUID(),
        name: "Assam State Control Room",
        organization: "Assam State Emergency",
        phone: "0361-2237154",
        email: "assam.emergency@gov.in",
        contactType: "state_control",
        state: "Assam",
        isActive: true,
      },
      {
        id: randomUUID(),
        name: "Medical Emergency",
        organization: "108 Helpline",
        phone: "108",
        email: "medical108@gov.in",
        contactType: "medical",
        state: "National",
        isActive: true,
      },
      {
        id: randomUUID(),
        name: "IMD Weather",
        organization: "Indian Meteorological Department",
        phone: "1596",
        email: "imd@gov.in",
        contactType: "weather",
        state: "National",
        isActive: true,
      },
    ];

    contacts.forEach(contact => {
      this.emergencyContacts.set(contact.id, contact);
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      role: insertUser.role || 'user',
      email: insertUser.email || null,
      phone: insertUser.phone || null,
      language: insertUser.language || 'en',
      notificationSettings: insertUser.notificationSettings || { sms: true, email: true, push: false }
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Monitoring Stations
  async getMonitoringStations(): Promise<MonitoringStation[]> {
    return Array.from(this.monitoringStations.values());
  }

  async getMonitoringStation(stationId: string): Promise<MonitoringStation | undefined> {
    return this.monitoringStations.get(stationId);
  }

  async createMonitoringStation(station: InsertMonitoringStation): Promise<MonitoringStation> {
    const id = randomUUID();
    const newStation: MonitoringStation = {
      ...station,
      id,
      isActive: station.isActive ?? true,
      lastMaintenance: station.lastMaintenance || null,
      createdAt: new Date(),
    };
    this.monitoringStations.set(station.stationId, newStation);
    return newStation;
  }

  async updateMonitoringStation(stationId: string, updates: Partial<MonitoringStation>): Promise<MonitoringStation | undefined> {
    const station = this.monitoringStations.get(stationId);
    if (!station) return undefined;
    const updatedStation = { ...station, ...updates };
    this.monitoringStations.set(stationId, updatedStation);
    return updatedStation;
  }

  // Water Level Readings
  async getWaterLevelReadings(stationId?: string, limit?: number): Promise<WaterLevelReading[]> {
    let readings = this.waterLevelReadings;
    if (stationId) {
      readings = readings.filter(r => r.stationId === stationId);
    }
    readings.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    if (limit) {
      readings = readings.slice(0, limit);
    }
    return readings;
  }

  async createWaterLevelReading(reading: InsertWaterLevelReading): Promise<WaterLevelReading> {
    const id = randomUUID();
    const newReading: WaterLevelReading = {
      ...reading,
      id,
      temperature: reading.temperature || null,
      rainfall: reading.rainfall || null,
      timestamp: new Date(),
    };
    this.waterLevelReadings.push(newReading);
    return newReading;
  }

  async getLatestReadings(): Promise<WaterLevelReading[]> {
    const latestByStation = new Map<string, WaterLevelReading>();
    
    this.waterLevelReadings
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .forEach(reading => {
        if (!latestByStation.has(reading.stationId)) {
          latestByStation.set(reading.stationId, reading);
        }
      });

    return Array.from(latestByStation.values());
  }

  // Alerts
  async getAlerts(isActive?: boolean): Promise<Alert[]> {
    let alerts = Array.from(this.alerts.values());
    if (isActive !== undefined) {
      alerts = alerts.filter(alert => alert.isActive === isActive);
    }
    return alerts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getAlert(id: string): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const newAlert: Alert = {
      ...alert,
      id,
      isActive: alert.isActive ?? true,
      acknowledgedBy: alert.acknowledgedBy || null,
      acknowledgedAt: alert.acknowledgedAt || null,
      resolvedAt: alert.resolvedAt || null,
      createdAt: new Date(),
    };
    this.alerts.set(id, newAlert);
    return newAlert;
  }

  async updateAlert(id: string, updates: Partial<Alert>): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    const updatedAlert = { ...alert, ...updates };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }

  async getActiveAlertsByStation(stationId: string): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => alert.stationId === stationId && alert.isActive);
  }

  // Emergency Contacts
  async getEmergencyContacts(state?: string): Promise<EmergencyContact[]> {
    let contacts = Array.from(this.emergencyContacts.values());
    if (state) {
      contacts = contacts.filter(contact => contact.state === state || contact.state === "National");
    }
    return contacts.filter(contact => contact.isActive);
  }

  async createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact> {
    const id = randomUUID();
    const newContact: EmergencyContact = { 
      ...contact, 
      id,
      email: contact.email || null,
      state: contact.state || null,
      isActive: contact.isActive ?? true
    };
    this.emergencyContacts.set(id, newContact);
    return newContact;
  }

  // Notification Logs
  async createNotificationLog(log: InsertNotificationLog): Promise<NotificationLog> {
    const id = randomUUID();
    const newLog: NotificationLog = {
      ...log,
      id,
      errorMessage: log.errorMessage || null,
      sentAt: new Date(),
    };
    this.notificationLogs.push(newLog);
    return newLog;
  }

  async getNotificationLogs(alertId?: string): Promise<NotificationLog[]> {
    let logs = this.notificationLogs;
    if (alertId) {
      logs = logs.filter(log => log.alertId === alertId);
    }
    return logs.sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
  }
}

export const storage = new MemStorage();
