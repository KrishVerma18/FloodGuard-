import { storage } from "../storage";
import { type InsertWaterLevelReading } from "@shared/schema";

export class IoTSimulator {
  private intervalId: NodeJS.Timeout | null = null;
  private baseWaterLevels: Map<string, number> = new Map();

  constructor() {
    // Initialize base water levels for simulation
    this.initializeBaseLevels();
  }

  private async initializeBaseLevels() {
    const stations = await storage.getMonitoringStations();
    stations.forEach(station => {
      // Set initial levels based on current readings or normal levels
      let initialLevel = station.normalLevel;
      
      // Add some variation for realistic simulation
      if (station.stationId === "BR-001") {
        initialLevel = 45.2; // Danger level for Brahmaputra
      } else if (station.stationId === "GN-002") {
        initialLevel = 42.8; // Warning level for Ganga
      } else if (station.stationId === "YM-003") {
        initialLevel = 202.1; // Normal for Yamuna
      } else if (station.stationId === "PR-004") {
        initialLevel = 4.2; // Normal for Periyar
      }
      
      this.baseWaterLevels.set(station.stationId, initialLevel);
    });
  }

  public startSimulation() {
    if (this.intervalId) {
      this.stopSimulation();
    }

    // Generate readings every 30 seconds
    this.intervalId = setInterval(async () => {
      await this.generateReadings();
    }, 30000);

    console.log("IoT simulation started - generating readings every 30 seconds");
  }

  public stopSimulation() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      console.log("IoT simulation stopped");
    }
  }

  private async generateReadings() {
    const stations = await storage.getMonitoringStations();
    
    for (const station of stations) {
      if (!station.isActive) continue;

      const baseLevel = this.baseWaterLevels.get(station.stationId) || station.normalLevel;
      
      // Generate realistic variations
      let waterLevel = baseLevel;
      let variation = 0;

      // Different patterns for different stations
      if (station.stationId === "BR-001") {
        // Brahmaputra - slowly decreasing from danger level
        variation = Math.random() * 0.2 - 0.1; // ±0.1m
        waterLevel = Math.max(baseLevel + variation, station.dangerLevel);
      } else if (station.stationId === "GN-002") {
        // Ganga - fluctuating around warning level
        variation = Math.random() * 0.4 - 0.2; // ±0.2m
        waterLevel = baseLevel + variation;
      } else {
        // Other stations - normal fluctuations
        variation = Math.random() * 0.3 - 0.15; // ±0.15m
        waterLevel = Math.max(baseLevel + variation, 0);
      }

      // Update base level for next reading
      this.baseWaterLevels.set(station.stationId, waterLevel);

      // Generate reading
      const reading: InsertWaterLevelReading = {
        stationId: station.stationId,
        waterLevel: Math.round(waterLevel * 100) / 100, // Round to 2 decimal places
        temperature: Math.round((25 + Math.random() * 10) * 10) / 10, // 25-35°C
        rainfall: Math.round(Math.random() * 5 * 10) / 10, // 0-5mm
      };

      await storage.createWaterLevelReading(reading);
    }
  }

  public async generateInitialReadings() {
    // Generate some historical data
    const stations = await storage.getMonitoringStations();
    const now = new Date();

    for (const station of stations) {
      // Generate readings for the last 24 hours
      for (let i = 24; i >= 0; i--) {
        const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000); // Every hour
        const baseLevel = this.baseWaterLevels.get(station.stationId) || station.normalLevel;
        
        let waterLevel = baseLevel;
        if (i > 12) {
          // Earlier readings were lower
          waterLevel = baseLevel - (i - 12) * 0.1;
        }

        const reading: InsertWaterLevelReading = {
          stationId: station.stationId,
          waterLevel: Math.round(Math.max(waterLevel, 0) * 100) / 100,
          temperature: Math.round((25 + Math.random() * 10) * 10) / 10,
          rainfall: Math.round(Math.random() * 5 * 10) / 10,
        };

        const createdReading = await storage.createWaterLevelReading(reading);
        // Manually set the timestamp for historical data
        createdReading.timestamp = timestamp;
      }
    }
  }
}

export const iotSimulator = new IoTSimulator();
