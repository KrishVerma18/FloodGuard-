import { storage } from "../storage";
import { type InsertAlert, type MonitoringStation, type WaterLevelReading } from "@shared/schema";
import { notificationService } from "./notificationService";

export class AlertService {
  private processedReadings: Set<string> = new Set();

  public async processWaterLevelReading(reading: WaterLevelReading) {
    // Avoid processing the same reading multiple times
    if (this.processedReadings.has(reading.id)) {
      return;
    }
    this.processedReadings.add(reading.id);

    const station = await storage.getMonitoringStation(reading.stationId);
    if (!station) return;

    const alertType = this.determineAlertType(reading.waterLevel, station);
    if (!alertType) return;

    // Check if there's already an active alert of this type for this station
    const existingAlerts = await storage.getActiveAlertsByStation(reading.stationId);
    const hasExistingAlert = existingAlerts.some(alert => 
      alert.alertType === alertType && alert.isActive
    );

    if (hasExistingAlert) return;

    // Create new alert
    const alert = await this.createAlert(reading, station, alertType);
    
    // Send notifications
    await notificationService.sendAlertNotifications(alert, station);
  }

  private determineAlertType(waterLevel: number, station: MonitoringStation): string | null {
    if (waterLevel >= station.dangerLevel) {
      return "flood";
    } else if (waterLevel >= station.warningLevel) {
      return "warning";
    }
    return null;
  }

  private async createAlert(
    reading: WaterLevelReading, 
    station: MonitoringStation, 
    alertType: string
  ): Promise<any> {
    const severity = alertType === "flood" ? "critical" : "high";
    
    let title: string;
    let message: string;

    if (alertType === "flood") {
      title = `FLOOD WARNING: ${station.riverName} River - ${station.location}`;
      message = `${station.riverName} River has exceeded danger level at ${station.location}. Current level: ${reading.waterLevel}m (Danger: ${station.dangerLevel}m). Immediate evacuation recommended for low-lying areas.`;
    } else {
      title = `WATER LEVEL WARNING: ${station.riverName} River - ${station.location}`;
      message = `${station.riverName} River at ${station.location} approaching warning level. Current level: ${reading.waterLevel}m (Warning: ${station.warningLevel}m). Monitor closely for further rise.`;
    }

    const alertData: InsertAlert = {
      stationId: station.stationId,
      alertType,
      severity,
      title,
      message,
      isActive: true,
    };

    return await storage.createAlert(alertData);
  }

  public async acknowledgeAlert(alertId: string, userId: string) {
    return await storage.updateAlert(alertId, {
      acknowledgedBy: userId,
      acknowledgedAt: new Date(),
    });
  }

  public async resolveAlert(alertId: string) {
    return await storage.updateAlert(alertId, {
      isActive: false,
      resolvedAt: new Date(),
    });
  }

  public async getActiveAlerts() {
    return await storage.getAlerts(true);
  }

  public async getAllAlerts() {
    return await storage.getAlerts();
  }

  public async createSystemAlert(title: string, message: string) {
    const alertData: InsertAlert = {
      stationId: "SYSTEM",
      alertType: "system",
      severity: "medium",
      title,
      message,
      isActive: true,
    };

    return await storage.createAlert(alertData);
  }
}

export const alertService = new AlertService();
