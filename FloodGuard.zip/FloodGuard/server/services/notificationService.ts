import { storage } from "../storage";
import { type Alert, type MonitoringStation, type InsertNotificationLog } from "@shared/schema";

export class NotificationService {
  private twilioSid = process.env.TWILIO_SID || "test_twilio_sid";
  private twilioToken = process.env.TWILIO_TOKEN || "test_twilio_token";
  private twilioPhoneNumber = process.env.TWILIO_PHONE || "+1234567890";
  private smtpConfig = {
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: parseInt(process.env.SMTP_PORT || "587"),
    user: process.env.SMTP_USER || "flood.alerts@example.com",
    pass: process.env.SMTP_PASS || "test_password",
  };

  public async sendAlertNotifications(alert: Alert, station: MonitoringStation) {
    // Get users in the affected area (for now, get all users)
    // In a real implementation, this would be based on geographic location
    const affectedUsers: any[] = []; // await this.getUsersInArea(station);

    // For demonstration, we'll log the notifications
    console.log(`🚨 ALERT: ${alert.title}`);
    console.log(`📍 Location: ${station.location}, ${station.state}`);
    console.log(`💧 Water Level: Current readings exceed ${alert.severity} threshold`);
    console.log(`📱 Notifications would be sent to affected users`);

    // Send SMS notifications
    await this.sendSMSNotifications(alert, station, affectedUsers);
    
    // Send Email notifications
    await this.sendEmailNotifications(alert, station, affectedUsers);

    // Log notification attempts
    await this.logNotificationAttempt(alert.id, "broadcast", "sms", "sent");
    await this.logNotificationAttempt(alert.id, "broadcast", "email", "sent");
  }

  private async sendSMSNotifications(alert: Alert, station: MonitoringStation, users: any[]) {
    const message = this.formatSMSMessage(alert, station);
    
    // In a real implementation, integrate with Twilio
    console.log(`📱 SMS Alert would be sent: ${message}`);
    
    // Example Twilio integration (commented out for demo):
    /*
    const twilio = require('twilio')(this.twilioSid, this.twilioToken);
    
    for (const user of users) {
      if (user.phone && user.notificationSettings?.sms) {
        try {
          await twilio.messages.create({
            body: message,
            from: this.twilioPhoneNumber,
            to: user.phone
          });
          await this.logNotificationAttempt(alert.id, user.phone, "sms", "sent");
        } catch (error) {
          await this.logNotificationAttempt(alert.id, user.phone, "sms", "failed", error.message);
        }
      }
    }
    */
  }

  private async sendEmailNotifications(alert: Alert, station: MonitoringStation, users: any[]) {
    const { subject, html } = this.formatEmailMessage(alert, station);
    
    console.log(`📧 Email Alert would be sent:`);
    console.log(`Subject: ${subject}`);
    console.log(`Content: ${html.substring(0, 100)}...`);

    // Example Nodemailer integration (commented out for demo):
    /*
    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransporter({
      host: this.smtpConfig.host,
      port: this.smtpConfig.port,
      secure: false,
      auth: {
        user: this.smtpConfig.user,
        pass: this.smtpConfig.pass
      }
    });

    for (const user of users) {
      if (user.email && user.notificationSettings?.email) {
        try {
          await transporter.sendMail({
            from: this.smtpConfig.user,
            to: user.email,
            subject,
            html
          });
          await this.logNotificationAttempt(alert.id, user.email, "email", "sent");
        } catch (error) {
          await this.logNotificationAttempt(alert.id, user.email, "email", "failed", error.message);
        }
      }
    }
    */
  }

  private formatSMSMessage(alert: Alert, station: MonitoringStation): string {
    return `🚨 FLOOD ALERT\n${alert.title}\n📍 ${station.location}, ${station.state}\n${alert.message}\nStay safe and follow local evacuation orders.`;
  }

  private formatEmailMessage(alert: Alert, station: MonitoringStation): { subject: string; html: string } {
    const subject = `🚨 ${alert.title}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #dc2626; color: white; padding: 20px; text-align: center;">
          <h1 style="margin: 0;">🚨 FLOOD ALERT</h1>
        </div>
        <div style="padding: 20px; background: #f9fafb;">
          <h2 style="color: #dc2626;">${alert.title}</h2>
          <p><strong>Location:</strong> ${station.location}, ${station.state}</p>
          <p><strong>River:</strong> ${station.riverName}</p>
          <p><strong>Severity:</strong> ${alert.severity.toUpperCase()}</p>
          <div style="background: white; padding: 15px; border-left: 4px solid #dc2626; margin: 20px 0;">
            <p>${alert.message}</p>
          </div>
          <div style="background: #fef2f2; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #dc2626; margin-top: 0;">Safety Instructions:</h3>
            <ul>
              <li>Move to higher ground immediately</li>
              <li>Avoid walking or driving through flood water</li>
              <li>Follow local evacuation orders</li>
              <li>Keep emergency supplies ready</li>
              <li>Stay tuned to local news for updates</li>
            </ul>
          </div>
          <p style="color: #6b7280; font-size: 12px;">
            This is an automated alert from the Flood Monitoring System. 
            Time: ${new Date().toLocaleString()}
          </p>
        </div>
      </div>
    `;
    return { subject, html };
  }

  private async logNotificationAttempt(
    alertId: string, 
    recipient: string, 
    method: string, 
    status: string, 
    errorMessage?: string
  ) {
    const logData: InsertNotificationLog = {
      alertId,
      recipient,
      method,
      status,
      errorMessage,
    };
    
    await storage.createNotificationLog(logData);
  }

  public async sendTestNotification(method: "sms" | "email", recipient: string) {
    const testAlert = {
      id: "test-alert",
      title: "Test Alert",
      message: "This is a test notification from the Flood Monitoring System.",
      severity: "low" as const,
    };

    const testStation = {
      location: "Test Location",
      state: "Test State",
      riverName: "Test River",
    };

    if (method === "sms") {
      console.log(`📱 Test SMS would be sent to ${recipient}`);
      await this.logNotificationAttempt("test-alert", recipient, "sms", "sent");
    } else {
      console.log(`📧 Test Email would be sent to ${recipient}`);
      await this.logNotificationAttempt("test-alert", recipient, "email", "sent");
    }

    return { success: true, message: `Test ${method} notification logged successfully` };
  }
}

export const notificationService = new NotificationService();
