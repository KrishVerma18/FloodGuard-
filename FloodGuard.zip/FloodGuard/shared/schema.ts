import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  phone: text("phone"),
  role: text("role").notNull().default("user"), // user, admin, authority
  language: text("language").notNull().default("en"), // en, hi, bn, as
  notificationSettings: jsonb("notification_settings").default({
    sms: true,
    email: true,
    push: false
  }),
});

export const monitoringStations = pgTable("monitoring_stations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  stationId: text("station_id").notNull().unique(),
  riverName: text("river_name").notNull(),
  location: text("location").notNull(), // city/district
  state: text("state").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  normalLevel: real("normal_level").notNull(), // in meters
  warningLevel: real("warning_level").notNull(),
  dangerLevel: real("danger_level").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  lastMaintenance: timestamp("last_maintenance"),
  createdAt: timestamp("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const waterLevelReadings = pgTable("water_level_readings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stationId: text("station_id").notNull().references(() => monitoringStations.stationId),
  waterLevel: real("water_level").notNull(), // in meters
  temperature: real("temperature"), // in celsius
  rainfall: real("rainfall"), // in mm
  timestamp: timestamp("timestamp").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stationId: text("station_id").notNull().references(() => monitoringStations.stationId),
  alertType: text("alert_type").notNull(), // warning, danger, flood, system
  severity: text("severity").notNull(), // low, medium, high, critical
  title: text("title").notNull(),
  message: text("message").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  acknowledgedBy: text("acknowledged_by").references(() => users.id),
  acknowledgedAt: timestamp("acknowledged_at"),
  createdAt: timestamp("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  resolvedAt: timestamp("resolved_at"),
});

export const emergencyContacts = pgTable("emergency_contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  organization: text("organization").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  contactType: text("contact_type").notNull(), // ndrf, state_control, medical, weather
  state: text("state"),
  isActive: boolean("is_active").notNull().default(true),
});

export const notificationLogs = pgTable("notification_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  alertId: text("alert_id").notNull().references(() => alerts.id),
  recipient: text("recipient").notNull(), // phone or email
  method: text("method").notNull(), // sms, email, push
  status: text("status").notNull(), // sent, failed, delivered
  sentAt: timestamp("sent_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  errorMessage: text("error_message"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertMonitoringStationSchema = createInsertSchema(monitoringStations).omit({
  id: true,
  createdAt: true,
});

export const insertWaterLevelReadingSchema = createInsertSchema(waterLevelReadings).omit({
  id: true,
  timestamp: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).omit({
  id: true,
});

export const insertNotificationLogSchema = createInsertSchema(notificationLogs).omit({
  id: true,
  sentAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MonitoringStation = typeof monitoringStations.$inferSelect;
export type InsertMonitoringStation = z.infer<typeof insertMonitoringStationSchema>;

export type WaterLevelReading = typeof waterLevelReadings.$inferSelect;
export type InsertWaterLevelReading = z.infer<typeof insertWaterLevelReadingSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;

export type NotificationLog = typeof notificationLogs.$inferSelect;
export type InsertNotificationLog = z.infer<typeof insertNotificationLogSchema>;
